import { useEffect, useState } from 'react';
import { getBooks, getContinueReading } from '../lib/api.js';
import { SearchIcon, BellIcon } from '../components/ui/Icons.jsx';
import { IconButton } from '../components/ui/primitives.jsx';
import BookCard from '../components/book/BookCard.jsx';
import ContinueReadingCard from '../components/book/ContinueReadingCard.jsx';

export default function Home() {
  const [books, setBooks] = useState([]);
  const [continueEntry, setContinueEntry] = useState(null);

  useEffect(() => {
    getBooks().then(setBooks);
    getContinueReading().then(setContinueEntry);
  }, []);

  return (
    <div className="px-5 pt-7 pb-6">
      <div className="flex justify-between items-center mb-5">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold to-deep" />
        <div className="flex gap-2">
          <IconButton aria-label="Search">
            <SearchIcon className="w-4 h-4" />
          </IconButton>
          <IconButton aria-label="Notifications">
            <BellIcon className="w-4 h-4" />
          </IconButton>
        </div>
      </div>

      <h1 className="font-display font-medium text-[22px] mb-1">Good evening, Aïda</h1>
      <p className="text-[13px] text-taupe mb-6">Three stories are waiting where you left them.</p>

      {continueEntry && (
        <>
          <SectionTitle>Continue Reading</SectionTitle>
          <div className="mb-6">
            <ContinueReadingCard entry={continueEntry} />
          </div>
        </>
      )}

      <SectionTitle>For You</SectionTitle>
      <Rail books={books} />

      <SectionTitle>Trending This Week</SectionTitle>
      <Rail books={[...books].reverse()} />
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div className="text-[11px] tracking-widest uppercase text-taupe font-bold mb-3">
      {children}
    </div>
  );
}

function Rail({ books }) {
  return (
    <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1 mb-6">
      {books.map((b) => (
        <BookCard key={b.id} book={b} />
      ))}
    </div>
  );
}
