import { useEffect, useMemo, useState } from 'react';
import { getBooks } from '../lib/api.js';
import { SearchIcon } from '../components/ui/Icons.jsx';
import { covers } from '../lib/api.js';
import { CoverArt } from '../components/ui/primitives.jsx';
import { Link } from 'react-router-dom';

const genres = ['All', 'Literary Fiction', 'Mystery', 'Romance', 'Thriller', 'Drama'];

export default function Discover() {
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState('');
  const [genre, setGenre] = useState('All');

  useEffect(() => {
    getBooks().then(setBooks);
  }, []);

  const filtered = useMemo(() => {
    return books.filter((b) => {
      const matchesGenre = genre === 'All' || b.genres.includes(genre);
      const matchesQuery =
        query.trim() === '' ||
        b.title.toLowerCase().includes(query.toLowerCase()) ||
        b.author.toLowerCase().includes(query.toLowerCase());
      return matchesGenre && matchesQuery;
    });
  }, [books, query, genre]);

  return (
    <div className="px-5 pt-7 pb-6">
      <h1 className="font-display font-medium text-[22px] mb-4">Discover</h1>

      <label className="flex items-center gap-2 rounded-full bg-surface px-4 py-2.5 mb-4">
        <SearchIcon className="w-4 h-4 text-taupe flex-shrink-0" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search title or author"
          className="bg-transparent outline-none text-[13px] w-full placeholder:text-taupe"
        />
      </label>

      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6">
        {genres.map((g) => (
          <button
            key={g}
            onClick={() => setGenre(g)}
            className={`flex-shrink-0 text-[12px] font-semibold px-3.5 py-2 rounded-full border transition-colors ${
              genre === g
                ? 'bg-deep text-paper border-deep'
                : 'bg-white text-ink border-surface-line hover:border-gold hover:text-gold'
            }`}
          >
            {g}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        {filtered.map((b) => (
          <Link key={b.id} to={`/book/${b.id}`}>
            <CoverArt gradient={covers[b.cover]} className="w-full h-[150px]">
              <span className="font-display italic font-medium text-[13px] leading-tight">
                {b.title}
              </span>
            </CoverArt>
            <p className="mt-1.5 text-[12px] font-semibold truncate">{b.title}</p>
            <p className="text-[11px] text-taupe truncate">{b.author}</p>
          </Link>
        ))}
        {filtered.length === 0 && (
          <p className="col-span-2 text-[13px] text-taupe py-8 text-center">
            No stories match yet — try another title, author, or genre.
          </p>
        )}
      </div>
    </div>
  );
}
