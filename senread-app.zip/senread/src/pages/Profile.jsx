export default function Profile() {
  return (
    <div className="px-5 pt-7 pb-6">
      <h1 className="font-display font-medium text-[22px] mb-4">Profile</h1>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-gold to-deep" />
        <div>
          <p className="font-display font-semibold text-[15px]">Aïda Lefevre</p>
          <p className="text-[12px] text-taupe">Premium member</p>
        </div>
      </div>
      <div className="space-y-2">
        {['Reading preferences', 'Vocabulary review', 'Notifications', 'Subscription & coins'].map(
          (item) => (
            <div
              key={item}
              className="px-4 py-3.5 rounded-xl bg-white border border-surface-line text-[13px] font-medium"
            >
              {item}
            </div>
          )
        )}
      </div>
    </div>
  );
}
