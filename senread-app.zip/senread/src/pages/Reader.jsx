import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getChapter } from '../lib/api.js';
import { IconButton } from '../components/ui/primitives.jsx';
import { BackIcon, BookmarkIcon } from '../components/ui/Icons.jsx';
import BilingualSentence from '../components/reader/BilingualSentence.jsx';
import AudioBar from '../components/reader/AudioBar.jsx';

export default function Reader() {
  const { id, chapter } = useParams();
  const navigate = useNavigate();
  const [chapterData, setChapterData] = useState(null);

  useEffect(() => {
    getChapter(id, Number(chapter)).then(setChapterData);
  }, [id, chapter]);

  if (!chapterData) return null;

  return (
    <div className="min-h-screen bg-deep-2 text-paper px-5 pt-7 pb-6">
      <div className="flex justify-between items-center mb-5">
        <IconButton className="bg-paper/8 text-paper" onClick={() => navigate(-1)} aria-label="Go back">
          <BackIcon className="w-4 h-4" />
        </IconButton>
        <span className="text-[11px] text-gold-soft uppercase tracking-widest">
          {chapterData.title}
        </span>
        <IconButton className="bg-paper/8 text-paper" aria-label="Bookmark this page">
          <BookmarkIcon className="w-4 h-4" />
        </IconButton>
      </div>

      <div className="mb-6">
        {chapterData.sentences.map((s, i) => (
          <BilingualSentence key={i} en={s.en} fr={s.fr} />
        ))}
      </div>

      <AudioBar duration={chapterData.audioDuration} />
    </div>
  );
}
