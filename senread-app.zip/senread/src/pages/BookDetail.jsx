import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { getBook, covers } from '../lib/api.js';
import { IconButton, Tag, CoverArt } from '../components/ui/primitives.jsx';
import { BackIcon, BellIcon, PlayIcon, BookOpenIcon } from '../components/ui/Icons.jsx';

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);

  useEffect(() => {
    getBook(id).then(setBook);
  }, [id]);

  if (!book) return null;

  return (
    <div className="px-5 pt-6 pb-6">
      <div className="flex justify-between items-center mb-4">
        <IconButton aria-label="Go back" onClick={() => navigate(-1)}>
          <BackIcon className="w-4 h-4" />
        </IconButton>
        <IconButton aria-label="Notifications">
          <BellIcon className="w-4 h-4" />
        </IconButton>
      </div>

      <CoverArt
        gradient={covers[book.cover]}
        className="w-full h-[220px] items-center justify-center"
      >
        <BookOpenIcon className="w-12 h-12 opacity-25" />
      </CoverArt>

      <h1 className="font-display italic font-medium text-[24px] mt-5 mb-0.5">{book.title}</h1>
      <p className="text-[13px] text-taupe mb-4">by {book.author}</p>

      <div className="flex gap-1.5 flex-wrap mb-4">
        {book.genres.map((g) => (
          <Tag key={g}>{g}</Tag>
        ))}
        <Tag>{book.level}</Tag>
      </div>

      <div className="flex mb-4">
        <Stat value={book.chapterCount} label="Chapters" />
        <Stat value={book.readingTime} label="Reading" />
        <Stat value={book.rating} label="Rating" />
      </div>

      <p className="text-[13px] leading-relaxed text-[#4A4438] mb-6">{book.description}</p>

      <Link
        to={`/book/${book.id}/read/1`}
        className="flex items-center justify-center gap-2 bg-deep text-paper rounded-2xl py-4 font-semibold text-[13.5px]"
      >
        <PlayIcon className="w-3.5 h-3.5" />
        Start Reading
      </Link>
    </div>
  );
}

function Stat({ value, label }) {
  return (
    <div className="flex-1 text-left">
      <b className="block font-display text-[14px]">{value}</b>
      <span className="text-[10px] text-taupe uppercase tracking-wide">{label}</span>
    </div>
  );
}
