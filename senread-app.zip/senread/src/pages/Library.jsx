import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getLibrary, covers } from '../lib/api.js';
import { Ring } from '../components/ui/primitives.jsx';

const tabs = ['Reading', 'Bookmarked', 'Completed'];

export default function Library() {
  const [entries, setEntries] = useState([]);
  const [tab, setTab] = useState('Reading');

  useEffect(() => {
    getLibrary().then(setEntries);
  }, []);

  return (
    <div className="px-5 pt-7 pb-6">
      <h1 className="font-display font-medium text-[22px] mb-4">Library</h1>

      <div className="flex gap-5 border-b border-surface-line mb-4">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`text-[12.5px] font-semibold pb-2.5 ${
              tab === t ? 'text-ink border-b-2 border-gold' : 'text-taupe'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab !== 'Reading' ? (
        <p className="text-[13px] text-taupe py-10 text-center">
          Nothing here yet — {tab.toLowerCase()} stories will show up as you read.
        </p>
      ) : (
        <div>
          {entries.map((entry) => (
            <Link
              key={entry.bookId}
              to={`/book/${entry.bookId}/read/${entry.chapter}`}
              className="flex items-center gap-3 py-2.5 border-b border-surface-line"
            >
              <div
                className="w-[42px] h-[60px] rounded flex-shrink-0"
                style={{ background: covers[entry.book.cover] }}
              />
              <div className="flex-1 min-w-0">
                <p className="font-display font-semibold text-[13px] truncate">
                  {entry.book.title}
                </p>
                <p className="text-[10.5px] text-taupe">
                  Chapter {entry.chapter} of {entry.book.chapterCount}
                </p>
              </div>
              <Ring value={entry.progress} />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
