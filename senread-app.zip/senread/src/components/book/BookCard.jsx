import { Link } from 'react-router-dom';
import { covers } from '../../lib/api.js';
import { CoverArt } from '../ui/primitives.jsx';

export default function BookCard({ book }) {
  return (
    <Link
      to={`/book/${book.id}`}
      className="flex-shrink-0 w-[100px] focus-visible:outline-offset-4"
    >
      <CoverArt gradient={covers[book.cover]} className="w-[100px] h-[142px]">
        <span className="font-display italic font-medium text-[12px] leading-tight">
          {book.title}
        </span>
      </CoverArt>
      <p className="mt-1.5 text-[11px] text-taupe truncate">{book.author}</p>
    </Link>
  );
}
