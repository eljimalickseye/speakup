import { useState } from 'react';

/**
 * Signature reading element: the French translation never sits beside the
 * English sentence as a separate column. It sits beneath it, smaller,
 * italic, softened in tone and opacity - a second voice you can choose to
 * hear, not a lesson interrupting the story.
 *
 * Tapping a word is a lightweight stand-in for the future word-lookup
 * feature (definition, pronunciation, save to vocabulary).
 */
export default function BilingualSentence({ en, fr }) {
  const [activeWord, setActiveWord] = useState(null);

  const words = en.split(/(\s+)/);

  return (
    <div className="mb-5">
      <p className="font-reading text-[15.5px] leading-relaxed text-paper">
        {words.map((w, i) =>
          /^\s+$/.test(w) ? (
            <span key={i}>{w}</span>
          ) : (
            <span
              key={i}
              onClick={() => setActiveWord(activeWord === i ? null : i)}
              className={`cursor-pointer rounded transition-colors ${
                activeWord === i ? 'bg-gold-soft/25' : ''
              }`}
            >
              {w}
            </span>
          )
        )}
      </p>
      <p className="font-reading italic text-[12.5px] leading-snug text-[#8CA6A2] opacity-75 mt-1 pl-3.5 border-l border-[#8CA6A2]/35">
        {fr}
      </p>
    </div>
  );
}
