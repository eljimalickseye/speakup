import { useState } from 'react';
import { PlayIcon, PauseIcon } from '../ui/Icons.jsx';

export default function AudioBar({ duration = '5:40' }) {
  const [playing, setPlaying] = useState(false);

  return (
    <div className="flex items-center gap-3 rounded-2xl px-3.5 py-3 bg-paper/6 border border-paper/12">
      <button
        type="button"
        onClick={() => setPlaying((p) => !p)}
        aria-label={playing ? 'Pause narration' : 'Play narration'}
        className="w-8 h-8 rounded-full bg-gold text-deep-2 flex items-center justify-center flex-shrink-0"
      >
        {playing ? <PauseIcon className="w-3.5 h-3.5" /> : <PlayIcon className="w-3.5 h-3.5" />}
      </button>
      <div className="flex-1 h-[3px] rounded-full bg-paper/15">
        <div className="h-full w-[38%] rounded-full bg-gold-soft" />
      </div>
      <span className="text-[10px] text-[#8CA6A2]">{duration}</span>
    </div>
  );
}
