import { Outlet, useLocation } from 'react-router-dom';
import TabBar from './TabBar.jsx';

export default function AppShell() {
  const { pathname } = useLocation();
  // The reader view goes edge-to-edge and dark; hide the tab bar there
  // so nothing competes with the story.
  const isReader = pathname.includes('/read/');

  return (
    <div className="min-h-screen flex justify-center bg-paper">
      <div className="w-full max-w-md min-h-screen bg-paper relative flex flex-col shadow-[0_0_80px_-20px_rgba(18,42,40,0.15)]">
        <div className="flex-1 overflow-y-auto no-scrollbar">
          <Outlet />
        </div>
        {!isReader && <TabBar />}
      </div>
    </div>
  );
}
