import { NavLink } from 'react-router-dom';
import { HomeIcon, LibraryIcon, BookmarkIcon, ProfileIcon } from '../ui/Icons.jsx';

const tabs = [
  { to: '/', icon: HomeIcon, label: 'Home', end: true },
  { to: '/discover', icon: LibraryIcon, label: 'Discover' },
  { to: '/library', icon: BookmarkIcon, label: 'Library' },
  { to: '/profile', icon: ProfileIcon, label: 'Profile' },
];

export default function TabBar() {
  return (
    <nav className="sticky bottom-0 bg-paper border-t border-surface-line px-6 py-3 flex justify-around">
      {tabs.map(({ to, icon: Icon, label, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 text-[10px] font-medium transition-colors ${
              isActive ? 'text-gold' : 'text-[#B7AF9F]'
            }`
          }
        >
          <Icon className="w-5 h-5" />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}
