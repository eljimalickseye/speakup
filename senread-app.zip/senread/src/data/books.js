// Mock data layer.
// Shape is deliberately API-ready: swap the functions in src/lib/api.js
// for real fetch() calls later without touching any component.

export const covers = {
  c1: 'linear-gradient(160deg,#B08A4E,#4A3418)',
  c2: 'linear-gradient(160deg,#2E5250,#122A28)',
  c3: 'linear-gradient(160deg,#8C4A3E,#3B1D17)',
  c4: 'linear-gradient(160deg,#5C6B47,#243019)',
  c5: 'linear-gradient(160deg,#3E4A6E,#161C2E)',
};

export const books = [
  {
    id: 'salt-house',
    title: 'The Salt House',
    author: 'Léa Fontaine',
    cover: 'c2',
    genres: ['Literary Fiction', 'Coastal'],
    level: 'A2 · French',
    rating: 4.8,
    chapterCount: 14,
    readingTime: '4h 10m',
    description:
      "Every summer the tide takes something from the Duval house — this year, it takes a secret. A quiet, bilingual story of memory and the sea, told one sentence at a time in English, then French.",
  },
  {
    id: 'ember-streets',
    title: 'Ember Streets',
    author: 'Théo Mercier',
    cover: 'c1',
    genres: ['Mystery', 'Urban'],
    level: 'B1 · French',
    rating: 4.6,
    chapterCount: 18,
    readingTime: '5h 40m',
    description:
      'A city detective and a language she half-remembers from childhood, chasing a case that keeps switching tongues on her.',
  },
  {
    id: 'quiet-debt',
    title: 'The Quiet Debt',
    author: 'Inès Rambert',
    cover: 'c3',
    genres: ['Drama', 'Family'],
    level: 'A2 · French',
    rating: 4.5,
    chapterCount: 20,
    readingTime: '6h 05m',
    description:
      'Three siblings inherit a house, a business, and a silence none of them wants to break first.',
  },
  {
    id: 'orchards-end',
    title: "Orchard's End",
    author: 'Camille Dubois',
    cover: 'c4',
    genres: ['Romance', 'Countryside'],
    level: 'A1 · French',
    rating: 4.9,
    chapterCount: 12,
    readingTime: '3h 20m',
    description:
      'A season of apple harvests, an old letter, and two people who keep almost saying the right thing.',
  },
  {
    id: 'midnight-ledger',
    title: 'Midnight Ledger',
    author: 'Sacha Blanchard',
    cover: 'c5',
    genres: ['Thriller'],
    level: 'B2 · French',
    rating: 4.4,
    chapterCount: 16,
    readingTime: '4h 50m',
    description:
      'A bookkeeper finds one wrong number, and the wrong number finds her back.',
  },
];

export const chapters = {
  'salt-house': [
    {
      number: 7,
      title: 'Chapter Seven',
      audioDuration: '5:40',
      sentences: [
        {
          en: 'The lighthouse had not turned in three years, yet Marion still counted its silence like breath.',
          fr: "Le phare ne s'était pas allumé depuis trois ans, mais Marion comptait encore son silence comme un souffle.",
        },
        {
          en: 'She kept the key anyway, warm from her pocket, waiting for a night that might ask for it.',
          fr: 'Elle gardait quand même la clé, tiède dans sa poche, attendant une nuit qui la réclamerait.',
        },
        {
          en: 'Tonight, the fog came in low and certain, the way it always did before the truth did.',
          fr: 'Ce soir, le brouillard s\u2019installait, bas et certain, comme toujours avant la vérité.',
        },
      ],
    },
  ],
};

export const library = [
  { bookId: 'salt-house', status: 'reading', progress: 0.52, chapter: 7 },
  { bookId: 'quiet-debt', status: 'reading', progress: 0.1, chapter: 2 },
  { bookId: 'orchards-end', status: 'reading', progress: 0.92, chapter: 11 },
  { bookId: 'ember-streets', status: 'reading', progress: 0.04, chapter: 1 },
  { bookId: 'midnight-ledger', status: 'reading', progress: 0.22, chapter: 4 },
];
